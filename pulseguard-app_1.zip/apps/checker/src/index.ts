import { PrismaClient, ServiceStatus } from '@prisma/client';

const prisma = new PrismaClient();

const DEGRADED_THRESHOLD_MS = Number(process.env.DEGRADED_THRESHOLD_MS ?? 2000);

async function checkOne(service: { id: string; checkUrl: string; timeoutMs: number }) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), service.timeoutMs);
  const start = Date.now();

  let status: ServiceStatus = 'OPERATIONAL';
  let statusCode: number | null = null;
  let errorMessage: string | null = null;

  try {
    const res = await fetch(service.checkUrl, { signal: controller.signal, method: 'GET' });
    statusCode = res.status;
    const elapsed = Date.now() - start;

    if (!res.ok) {
      status = 'OUTAGE';
      errorMessage = `Unexpected status code ${res.status}`;
    } else if (elapsed > DEGRADED_THRESHOLD_MS) {
      status = 'DEGRADED';
    } else {
      status = 'OPERATIONAL';
    }
  } catch (err: any) {
    status = 'OUTAGE';
    errorMessage = err?.name === 'AbortError' ? `Timed out after ${service.timeoutMs}ms` : String(err?.message ?? err);
  } finally {
    clearTimeout(timer);
  }

  const responseMs = Date.now() - start;

  await prisma.$transaction([
    prisma.check.create({
      data: { serviceId: service.id, status, responseMs, statusCode: statusCode ?? undefined, errorMessage: errorMessage ?? undefined },
    }),
    prisma.service.update({ where: { id: service.id }, data: { currentStatus: status } }),
  ]);

  console.log(`[${status}] ${service.checkUrl} — ${responseMs}ms${errorMessage ? ` (${errorMessage})` : ''}`);
}

async function main() {
  const services = await prisma.service.findMany({
    select: { id: true, checkUrl: true, timeoutMs: true },
  });

  if (services.length === 0) {
    console.log('No services configured — nothing to check.');
    return;
  }

  const results = await Promise.allSettled(services.map(checkOne));
  const failed = results.filter((r) => r.status === 'rejected');
  if (failed.length > 0) {
    console.error(`${failed.length}/${services.length} checks failed to record.`);
  }
  console.log(`Checked ${services.length} service(s).`);
}

main()
  .catch((err) => {
    console.error('Checker run failed:', err);
    process.exitCode = 1;
  })
  .finally(() => prisma.$disconnect());
