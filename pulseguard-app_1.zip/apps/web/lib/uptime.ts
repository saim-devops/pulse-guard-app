import { Status } from '@/lib/status';

type CheckLike = { status: Status; checkedAt: Date };

export function dailyHistory(checks: CheckLike[], windowDays = 90) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const byDay = new Map<string, Status[]>();
  for (const c of checks) {
    const d = new Date(c.checkedAt);
    d.setHours(0, 0, 0, 0);
    const key = d.toISOString().slice(0, 10);
    if (!byDay.has(key)) byDay.set(key, []);
    byDay.get(key)!.push(c.status);
  }

  const days: { date: string; status: Status }[] = [];
  for (let i = windowDays - 1; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    const statuses = byDay.get(key);
    let status: Status = 'UNKNOWN';
    if (statuses && statuses.length) {
      if (statuses.includes('OUTAGE')) status = 'OUTAGE';
      else if (statuses.includes('DEGRADED')) status = 'DEGRADED';
      else status = 'OPERATIONAL';
    }
    days.push({ date: key, status });
  }
  return days;
}

export function uptimePercent(checks: CheckLike[]): number {
  const known = checks.filter((c) => c.status !== 'UNKNOWN');
  if (known.length === 0) return NaN;
  const up = known.filter((c) => c.status === 'OPERATIONAL').length;
  return (up / known.length) * 100;
}
