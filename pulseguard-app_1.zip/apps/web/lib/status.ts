export type Status = 'OPERATIONAL' | 'DEGRADED' | 'OUTAGE' | 'UNKNOWN';

export const statusCopy: Record<Status, string> = {
  OPERATIONAL: 'Operational',
  DEGRADED: 'Degraded',
  OUTAGE: 'Outage',
  UNKNOWN: 'Pending first check',
};

export const statusClasses: Record<Status, { dot: string; text: string; bg: string }> = {
  OPERATIONAL: { dot: 'bg-ok', text: 'text-ok', bg: 'bg-ok-bg' },
  DEGRADED: { dot: 'bg-warn', text: 'text-warn', bg: 'bg-warn-bg' },
  OUTAGE: { dot: 'bg-bad', text: 'text-bad', bg: 'bg-bad-bg' },
  UNKNOWN: { dot: 'bg-muted', text: 'text-muted', bg: 'bg-line' },
};

export function overallStatus(statuses: Status[]): Status {
  if (statuses.some((s) => s === 'OUTAGE')) return 'OUTAGE';
  if (statuses.some((s) => s === 'DEGRADED')) return 'DEGRADED';
  if (statuses.every((s) => s === 'UNKNOWN')) return 'UNKNOWN';
  return 'OPERATIONAL';
}

export function formatUptime(pct: number): string {
  if (Number.isNaN(pct)) return '—';
  return `${pct.toFixed(2)}%`;
}
