import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        paper: '#FAFAF8',
        surface: '#FFFFFF',
        ink: '#14171F',
        muted: '#5B5F6B',
        line: '#E4E4E0',
        brand: {
          DEFAULT: '#3B31E0',
          light: '#EDEBFC',
          dark: '#241C9E',
        },
        ok: { DEFAULT: '#1F9D6F', bg: '#E7F6EF' },
        warn: { DEFAULT: '#D98C1B', bg: '#FBF1DF' },
        bad: { DEFAULT: '#D8433A', bg: '#FBE9E8' },
      },
      fontFamily: {
        display: ['var(--font-fraunces)', 'serif'],
        sans: ['var(--font-inter)', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace'],
      },
      borderRadius: {
        card: '14px',
      },
    },
  },
  plugins: [],
};

export default config;
