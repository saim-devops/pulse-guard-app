'use client';

import { useEffect, useState } from 'react';

type Service = { id: string; name: string };
type Incident = {
  id: string;
  title: string;
  status: string;
  impact: string;
  updates: { message: string; status: string; createdAt: string }[];
  services: { service: Service }[];
};

export default function IncidentsPage() {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [form, setForm] = useState({ title: '', message: '', impact: 'MINOR', serviceIds: [] as string[] });
  const [updateDrafts, setUpdateDrafts] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);

  async function load() {
    const [i, s] = await Promise.all([fetch('/api/incidents').then((r) => r.json()), fetch('/api/services').then((r) => r.json())]);
    setIncidents(i);
    setServices(s);
  }

  useEffect(() => {
    load();
  }, []);

  async function onCreate(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const res = await fetch('/api/incidents', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error ?? 'Could not create incident.');
      return;
    }
    setForm({ title: '', message: '', impact: 'MINOR', serviceIds: [] });
    load();
  }

  async function postUpdate(id: string, status: string) {
    const message = updateDrafts[id];
    if (!message) return;
    await fetch(`/api/incidents/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, message }),
    });
    setUpdateDrafts({ ...updateDrafts, [id]: '' });
    load();
  }

  return (
    <div>
      <h1 className="font-display text-3xl italic text-ink">Incidents</h1>

      <form onSubmit={onCreate} className="mt-8 space-y-3 rounded-card border border-line bg-surface p-5">
        <input
          placeholder="Incident title"
          required
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          className="w-full rounded-lg border border-line px-3 py-2 text-sm outline-none focus:border-brand"
        />
        <textarea
          placeholder="Initial update message"
          required
          value={form.message}
          onChange={(e) => setForm({ ...form, message: e.target.value })}
          className="w-full rounded-lg border border-line px-3 py-2 text-sm outline-none focus:border-brand"
          rows={2}
        />
        <div className="flex flex-wrap items-center gap-4">
          <select
            value={form.impact}
            onChange={(e) => setForm({ ...form, impact: e.target.value })}
            className="rounded-lg border border-line px-3 py-2 text-sm outline-none focus:border-brand"
          >
            <option value="MINOR">Minor</option>
            <option value="MAJOR">Major</option>
            <option value="CRITICAL">Critical</option>
          </select>
          <div className="flex flex-wrap gap-2">
            {services.map((s) => (
              <label key={s.id} className="flex items-center gap-1 text-sm text-muted">
                <input
                  type="checkbox"
                  checked={form.serviceIds.includes(s.id)}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      serviceIds: e.target.checked ? [...form.serviceIds, s.id] : form.serviceIds.filter((id) => id !== s.id),
                    })
                  }
                />
                {s.name}
              </label>
            ))}
          </div>
        </div>
        {error && <p className="text-sm text-bad">{error}</p>}
        <button type="submit" className="rounded-lg bg-brand px-4 py-2 text-sm font-medium text-white hover:opacity-90">
          Declare incident
        </button>
      </form>

      <div className="mt-8 space-y-4">
        {incidents.map((inc) => (
          <div key={inc.id} className="rounded-card border border-line bg-surface p-5">
            <div className="flex items-center justify-between">
              <h3 className="font-medium text-ink">{inc.title}</h3>
              <span className="font-mono text-xs uppercase text-muted">{inc.status}</span>
            </div>
            <p className="mt-1 text-xs text-muted">Affects {inc.services.map((s) => s.service.name).join(', ')}</p>
            <ul className="mt-3 space-y-1 border-l border-line pl-3">
              {inc.updates.map((u, i) => (
                <li key={i} className="text-sm text-muted">
                  <span className="font-mono text-xs uppercase text-ink">{u.status}</span> — {u.message}
                </li>
              ))}
            </ul>
            {inc.status !== 'RESOLVED' && (
              <div className="mt-4 flex flex-wrap gap-2">
                <input
                  placeholder="Post an update…"
                  value={updateDrafts[inc.id] ?? ''}
                  onChange={(e) => setUpdateDrafts({ ...updateDrafts, [inc.id]: e.target.value })}
                  className="flex-1 rounded-lg border border-line px-3 py-2 text-sm outline-none focus:border-brand"
                />
                <button onClick={() => postUpdate(inc.id, 'MONITORING')} className="rounded-lg border border-line px-3 py-2 text-sm hover:border-brand">
                  Post update
                </button>
                <button onClick={() => postUpdate(inc.id, 'RESOLVED')} className="rounded-lg bg-ok px-3 py-2 text-sm text-white hover:opacity-90">
                  Resolve
                </button>
              </div>
            )}
          </div>
        ))}
        {incidents.length === 0 && <p className="text-sm text-muted">No incidents recorded.</p>}
      </div>
    </div>
  );
}
