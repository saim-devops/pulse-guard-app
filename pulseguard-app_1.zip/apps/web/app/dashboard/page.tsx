import { prisma } from '@/lib/db';
import Link from 'next/link';

export const dynamic = 'force-dynamic';

export default async function DashboardHome() {
  const [total, operational, degraded, outage, activeIncidents] = await Promise.all([
    prisma.service.count(),
    prisma.service.count({ where: { currentStatus: 'OPERATIONAL' } }),
    prisma.service.count({ where: { currentStatus: 'DEGRADED' } }),
    prisma.service.count({ where: { currentStatus: 'OUTAGE' } }),
    prisma.incident.count({ where: { status: { not: 'RESOLVED' } } }),
  ]);

  const stats = [
    { label: 'Services', value: total },
    { label: 'Operational', value: operational },
    { label: 'Degraded', value: degraded },
    { label: 'Outage', value: outage },
    { label: 'Active incidents', value: activeIncidents },
  ];

  return (
    <div>
      <h1 className="font-display text-3xl italic text-ink">Overview</h1>
      <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-5">
        {stats.map((s) => (
          <div key={s.label} className="rounded-card border border-line bg-surface p-5">
            <p className="font-mono text-2xl text-ink">{s.value}</p>
            <p className="mt-1 text-xs text-muted">{s.label}</p>
          </div>
        ))}
      </div>
      <div className="mt-8 flex gap-4">
        <Link href="/dashboard/services" className="rounded-lg bg-brand px-4 py-2 text-sm font-medium text-white hover:opacity-90">
          Manage services
        </Link>
        <Link href="/dashboard/incidents" className="rounded-lg border border-line bg-surface px-4 py-2 text-sm font-medium text-ink hover:border-brand">
          Manage incidents
        </Link>
      </div>
    </div>
  );
}
