import { redirect } from 'next/navigation';
import Link from 'next/link';
import { getSession } from '@/lib/auth';
import SignOutButton from '@/components/SignOutButton';

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();
  if (!session) redirect('/login');

  return (
    <div className="min-h-screen">
      <nav className="border-b border-line bg-surface">
        <div className="mx-auto flex max-w-4xl items-center justify-between px-6 py-4">
          <Link href="/dashboard" className="font-display text-lg italic text-ink">
            PulseGuard
          </Link>
          <div className="flex items-center gap-5 font-mono text-xs uppercase tracking-wide text-muted">
            <Link href="/dashboard/services" className="hover:text-ink">
              Services
            </Link>
            <Link href="/dashboard/incidents" className="hover:text-ink">
              Incidents
            </Link>
            <Link href="/" className="hover:text-ink">
              Status page
            </Link>
            <SignOutButton />
          </div>
        </div>
      </nav>
      <div className="mx-auto max-w-4xl px-6 py-10">{children}</div>
    </div>
  );
}
