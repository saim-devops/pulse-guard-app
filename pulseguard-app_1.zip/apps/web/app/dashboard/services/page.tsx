'use client';

import { useEffect, useState } from 'react';

type Service = {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  checkUrl: string;
  checkInterval: number;
  isPublic: boolean;
  currentStatus: string;
};

const emptyForm = { name: '', slug: '', description: '', checkUrl: '', checkInterval: 60, isPublic: true };

export default function ServicesPage() {
  const [services, setServices] = useState<Service[]>([]);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function load() {
    const res = await fetch('/api/services');
    setServices(await res.json());
  }

  useEffect(() => {
    load();
  }, []);

  async function onCreate(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const res = await fetch('/api/services', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });
    setLoading(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error ?? 'Could not create service.');
      return;
    }
    setForm(emptyForm);
    load();
  }

  async function onDelete(id: string) {
    if (!confirm('Delete this service? This also deletes its check history.')) return;
    await fetch(`/api/services/${id}`, { method: 'DELETE' });
    load();
  }

  return (
    <div>
      <h1 className="font-display text-3xl italic text-ink">Services</h1>

      <form onSubmit={onCreate} className="mt-8 grid grid-cols-1 gap-3 rounded-card border border-line bg-surface p-5 sm:grid-cols-2">
        <input
          placeholder="Name (e.g. API)"
          required
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="rounded-lg border border-line px-3 py-2 text-sm outline-none focus:border-brand"
        />
        <input
          placeholder="Slug (e.g. api)"
          required
          value={form.slug}
          onChange={(e) => setForm({ ...form, slug: e.target.value })}
          className="rounded-lg border border-line px-3 py-2 text-sm outline-none focus:border-brand"
        />
        <input
          placeholder="Check URL (https://…)"
          required
          value={form.checkUrl}
          onChange={(e) => setForm({ ...form, checkUrl: e.target.value })}
          className="rounded-lg border border-line px-3 py-2 text-sm outline-none focus:border-brand sm:col-span-2"
        />
        <input
          placeholder="Description (optional)"
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          className="rounded-lg border border-line px-3 py-2 text-sm outline-none focus:border-brand sm:col-span-2"
        />
        <label className="flex items-center gap-2 text-sm text-muted">
          <input
            type="number"
            min={15}
            value={form.checkInterval}
            onChange={(e) => setForm({ ...form, checkInterval: Number(e.target.value) })}
            className="w-24 rounded-lg border border-line px-3 py-2 text-sm outline-none focus:border-brand"
          />
          check interval (seconds)
        </label>
        <label className="flex items-center gap-2 text-sm text-muted">
          <input type="checkbox" checked={form.isPublic} onChange={(e) => setForm({ ...form, isPublic: e.target.checked })} />
          show on public status page
        </label>
        {error && <p className="text-sm text-bad sm:col-span-2">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="rounded-lg bg-brand px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50 sm:col-span-2"
        >
          {loading ? 'Adding…' : 'Add service'}
        </button>
      </form>

      <div className="mt-8 divide-y divide-line rounded-card border border-line bg-surface">
        {services.map((s) => (
          <div key={s.id} className="flex items-center justify-between gap-4 p-5">
            <div>
              <p className="font-medium text-ink">{s.name}</p>
              <p className="font-mono text-xs text-muted">{s.checkUrl}</p>
            </div>
            <div className="flex items-center gap-3">
              <span className="font-mono text-xs uppercase text-muted">{s.currentStatus}</span>
              <button onClick={() => onDelete(s.id)} className="text-sm text-bad hover:underline">
                Delete
              </button>
            </div>
          </div>
        ))}
        {services.length === 0 && <p className="p-5 text-sm text-muted">No services yet — add one above.</p>}
      </div>
    </div>
  );
}
