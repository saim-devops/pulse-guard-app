import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getSession } from '@/lib/auth';

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Not authenticated.' }, { status: 401 });

  const body = await req.json();
  const service = await prisma.service.update({
    where: { id: params.id },
    data: {
      name: body.name,
      description: body.description,
      checkUrl: body.checkUrl,
      checkInterval: body.checkInterval,
      timeoutMs: body.timeoutMs,
      isPublic: body.isPublic,
      sortOrder: body.sortOrder,
    },
  });
  return NextResponse.json(service);
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Not authenticated.' }, { status: 401 });

  await prisma.service.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
