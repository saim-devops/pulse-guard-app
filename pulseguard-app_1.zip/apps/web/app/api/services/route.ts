import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getSession } from '@/lib/auth';

export async function GET() {
  const session = await getSession();
  const services = await prisma.service.findMany({
    where: session ? undefined : { isPublic: true },
    orderBy: { sortOrder: 'asc' },
  });
  return NextResponse.json(services);
}

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Not authenticated.' }, { status: 401 });

  const body = await req.json();
  if (!body.name || !body.slug || !body.checkUrl) {
    return NextResponse.json({ error: 'name, slug, and checkUrl are required.' }, { status: 400 });
  }

  const service = await prisma.service.create({
    data: {
      name: body.name,
      slug: body.slug,
      description: body.description ?? null,
      checkUrl: body.checkUrl,
      checkInterval: body.checkInterval ?? 60,
      timeoutMs: body.timeoutMs ?? 5000,
      isPublic: body.isPublic ?? true,
      sortOrder: body.sortOrder ?? 0,
    },
  });
  return NextResponse.json(service, { status: 201 });
}
