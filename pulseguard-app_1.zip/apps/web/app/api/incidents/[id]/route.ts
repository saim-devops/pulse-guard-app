import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getSession } from '@/lib/auth';

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Not authenticated.' }, { status: 401 });

  const body = await req.json();
  if (!body.status || !body.message) {
    return NextResponse.json({ error: 'status and message are required.' }, { status: 400 });
  }

  const incident = await prisma.incident.update({
    where: { id: params.id },
    data: {
      status: body.status,
      resolvedAt: body.status === 'RESOLVED' ? new Date() : null,
      updates: { create: { status: body.status, message: body.message } },
    },
    include: { services: true },
  });

  if (body.status === 'RESOLVED') {
    await prisma.service.updateMany({
      where: { id: { in: incident.services.map((s) => s.serviceId) } },
      data: { currentStatus: 'OPERATIONAL' },
    });
  }

  return NextResponse.json(incident);
}
