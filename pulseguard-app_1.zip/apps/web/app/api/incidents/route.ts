import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getSession } from '@/lib/auth';

export async function GET() {
  const incidents = await prisma.incident.findMany({
    orderBy: { createdAt: 'desc' },
    include: { updates: { orderBy: { createdAt: 'desc' } }, services: { include: { service: true } } },
  });
  return NextResponse.json(incidents);
}

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Not authenticated.' }, { status: 401 });

  const body = await req.json();
  if (!body.title || !body.serviceIds?.length || !body.message) {
    return NextResponse.json({ error: 'title, message, and serviceIds are required.' }, { status: 400 });
  }

  const incident = await prisma.incident.create({
    data: {
      title: body.title,
      impact: body.impact ?? 'MINOR',
      status: 'INVESTIGATING',
      updates: { create: { status: 'INVESTIGATING', message: body.message } },
      services: { create: body.serviceIds.map((id: string) => ({ serviceId: id })) },
    },
    include: { updates: true, services: true },
  });

  await prisma.service.updateMany({
    where: { id: { in: body.serviceIds } },
    data: { currentStatus: body.impact === 'CRITICAL' ? 'OUTAGE' : 'DEGRADED' },
  });

  return NextResponse.json(incident, { status: 201 });
}
