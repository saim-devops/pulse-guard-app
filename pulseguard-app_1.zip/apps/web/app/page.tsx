import Link from 'next/link';
import { prisma } from '@/lib/db';
import { overallStatus, Status } from '@/lib/status';
import { dailyHistory, uptimePercent } from '@/lib/uptime';
import Heartbeat from '@/components/Heartbeat';
import StatusBadge from '@/components/StatusBadge';
import UptimeBar from '@/components/UptimeBar';

export const dynamic = 'force-dynamic';

export default async function StatusPage() {
  const services = await prisma.service.findMany({
    where: { isPublic: true },
    orderBy: { sortOrder: 'asc' },
    include: {
      checks: { orderBy: { checkedAt: 'desc' }, take: 500 },
    },
  });

  const activeIncidents = await prisma.incident.findMany({
    where: { status: { not: 'RESOLVED' } },
    orderBy: { createdAt: 'desc' },
    include: { updates: { orderBy: { createdAt: 'desc' }, take: 1 }, services: { include: { service: true } } },
  });

  const overall = overallStatus(services.map((s) => s.currentStatus as Status));

  return (
    <main className="mx-auto max-w-3xl px-6 py-16 sm:py-24">
      <header className="relative mb-14 text-center">
        <Heartbeat />
        <p className="relative font-mono text-xs uppercase tracking-[0.2em] text-muted">PulseGuard</p>
        <h1 className="relative mt-3 font-display text-4xl italic tracking-tight text-ink sm:text-5xl">
          {overall === 'OPERATIONAL' ? 'All systems normal' : overall === 'DEGRADED' ? 'Partial disruption' : overall === 'OUTAGE' ? 'Active outage' : 'Awaiting first check'}
        </h1>
        <div className="relative mt-5 flex justify-center">
          <StatusBadge status={overall} />
        </div>
      </header>

      {activeIncidents.length > 0 && (
        <section className="mb-10 space-y-3">
          {activeIncidents.map((inc) => (
            <div key={inc.id} className="rounded-card border border-line bg-surface p-5">
              <div className="flex items-center justify-between">
                <h3 className="font-medium text-ink">{inc.title}</h3>
                <span className="font-mono text-xs uppercase tracking-wide text-muted">{inc.status.replace('_', ' ')}</span>
              </div>
              {inc.updates[0] && <p className="mt-2 text-sm text-muted">{inc.updates[0].message}</p>}
              <p className="mt-3 text-xs text-muted">
                Affects {inc.services.map((s) => s.service.name).join(', ')}
              </p>
            </div>
          ))}
        </section>
      )}

      <section className="space-y-8">
        {services.map((svc) => {
          const history = dailyHistory(svc.checks);
          const uptime = uptimePercent(svc.checks);
          return (
            <div key={svc.id} className="rounded-card border border-line bg-surface p-6">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h2 className="font-medium text-ink">{svc.name}</h2>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-sm text-muted">{Number.isNaN(uptime) ? '—' : `${uptime.toFixed(2)}%`} uptime</span>
                  <StatusBadge status={svc.currentStatus as Status} />
                </div>
              </div>
              {svc.description && <p className="mt-1 text-sm text-muted">{svc.description}</p>}
              <div className="mt-4">
                <UptimeBar days={history} />
              </div>
            </div>
          );
        })}

        {services.length === 0 && (
          <div className="rounded-card border border-dashed border-line p-10 text-center text-sm text-muted">
            No public services configured yet. Add one from the{' '}
            <Link href="/dashboard" className="text-brand underline underline-offset-2">
              dashboard
            </Link>
            .
          </div>
        )}
      </section>

      <footer className="mt-16 text-center font-mono text-xs text-muted">
        <Link href="/dashboard" className="hover:text-ink">
          Admin
        </Link>
      </footer>
    </main>
  );
}
