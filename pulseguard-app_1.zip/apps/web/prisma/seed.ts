import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  const email = process.env.ADMIN_EMAIL ?? 'admin@saimm.online';
  const password = process.env.ADMIN_PASSWORD ?? 'change-me-immediately';

  const passwordHash = await bcrypt.hash(password, 10);
  await prisma.user.upsert({
    where: { email },
    update: {},
    create: { email, passwordHash, name: 'Admin' },
  });
  console.log(`Admin user ready: ${email}`);

  const sample = [
    { name: 'API', slug: 'api', checkUrl: 'https://api.saimm.online/health', description: 'Core application API' },
    { name: 'Web app', slug: 'web', checkUrl: 'https://status.saimm.online', description: 'Customer-facing web app' },
    { name: 'Database', slug: 'database', checkUrl: 'https://api.saimm.online/health', description: 'Primary Postgres instance' },
  ];

  for (const [i, s] of sample.entries()) {
    await prisma.service.upsert({
      where: { slug: s.slug },
      update: {},
      create: { ...s, sortOrder: i },
    });
  }
  console.log('Sample services ready.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
