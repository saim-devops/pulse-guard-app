export default function Heartbeat() {
  return (
    <svg
      viewBox="0 0 800 120"
      className="pointer-events-none absolute inset-x-0 top-1/2 -z-0 h-24 w-full -translate-y-1/2 opacity-[0.16]"
      preserveAspectRatio="none"
      aria-hidden="true"
    >
      <path
        d="M0 60 H260 L290 60 L305 20 L322 100 L338 40 L352 60 H540 L560 60 L575 30 L590 90 L605 60 H800"
        fill="none"
        stroke="#3B31E0"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        pathLength="1000"
        style={{
          strokeDasharray: '1000',
          strokeDashoffset: '1000',
          animation: 'pg-draw 3.2s ease-in-out infinite',
        }}
      />
      <style>{`
        @keyframes pg-draw {
          0% { stroke-dashoffset: 1000; }
          55% { stroke-dashoffset: 0; }
          100% { stroke-dashoffset: -1000; }
        }
        @media (prefers-reduced-motion: reduce) {
          path { animation: none !important; stroke-dashoffset: 0 !important; }
        }
      `}</style>
    </svg>
  );
}
