import { Status } from '@/lib/status';

const barColor: Record<Status, string> = {
  OPERATIONAL: '#1F9D6F',
  DEGRADED: '#D98C1B',
  OUTAGE: '#D8433A',
  UNKNOWN: '#E4E4E0',
};

export default function UptimeBar({ days }: { days: { date: string; status: Status }[] }) {
  return (
    <div className="w-full">
      <div className="flex gap-[3px]">
        {days.map((d) => (
          <div
            key={d.date}
            title={`${d.date}: ${d.status}`}
            className="h-8 flex-1 rounded-[2px] transition-opacity hover:opacity-70"
            style={{ backgroundColor: barColor[d.status] }}
          />
        ))}
      </div>
      <div className="mt-2 flex justify-between font-mono text-xs text-muted">
        <span>{days.length} days ago</span>
        <span>today</span>
      </div>
    </div>
  );
}
