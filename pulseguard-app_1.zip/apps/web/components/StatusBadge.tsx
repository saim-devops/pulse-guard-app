import { Status, statusClasses, statusCopy } from '@/lib/status';

export default function StatusBadge({ status }: { status: Status }) {
  const c = statusClasses[status];
  return (
    <span className={`inline-flex items-center gap-2 rounded-full px-3 py-1 text-sm font-medium ${c.bg} ${c.text}`}>
      <span className={`h-2 w-2 rounded-full ${c.dot}`} />
      {statusCopy[status]}
    </span>
  );
}
